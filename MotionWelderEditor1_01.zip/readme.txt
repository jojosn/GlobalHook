-------------------------------------------------------------------------------
			MotionWelder 1.0
-------------------------------------------------------------------------------

MotionWelder release Note :
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Motion Welder is simple, free, GUI tool with rich user interface for fast and easy creation of image based animation, for java mobile game. It is specially designed to bridge a gap beetween developer and designer.Animation plotted by designer on Motion Welder, can be exported directly to java mobile game by developer, which save tremendous amount of both of the teams time, and helps in creating quality animation.


Why MotionWelder :
~~~~~~~~~~~~~~~~
Numerous reason to use Motion Welder, try it out. Check out our website for more detail.
Current version of MotionWelder is FREEWARE....Enjoy ! :-)

I want full version:
~~~~~~~~~~~~~~~~~~~~
For full version to create unlimited animation, write to support@motionwelder.com


How to install :
~~~~~~~~~~~~~~~~
Just unzip all the files into a directory you want then launch it.


Project web sites :
~~~~~~~~~~~~~~~~~~~
http://www.motionwelder.com/


Author:
~~~~~~~
Nitin Pokar (pokar.nitin@gmail.com, nitin@motionwelder.com)

-------------------------------------------------------------------------------
MotionWelder software is provided "as-is". 
No warranty of any kind is expressed or implied. 
-------------------------------------------------------------------------------
